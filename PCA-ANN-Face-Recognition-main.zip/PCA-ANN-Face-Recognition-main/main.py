import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score

# ---------------- PERMANENT PATH FIX ---------------- #

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_PATH = os.path.join(BASE_DIR, "faces")
IMPOSTER_PATH = os.path.join(BASE_DIR, "imposters")

IMG_SIZE = (100, 100)

# ---------------- LOAD FACE DATA ---------------- #

faces = []
labels = []
label_id = 0

print("Loading faces...")

for person in os.listdir(DATASET_PATH):
    person_path = os.path.join(DATASET_PATH, person)
    if os.path.isdir(person_path):
        for img_name in os.listdir(person_path):
            img_path = os.path.join(person_path, img_name)
            img = cv2.imread(img_path, 0)
            if img is not None:
                img = cv2.resize(img, IMG_SIZE)
                faces.append(img.flatten())
                labels.append(label_id)
        label_id += 1

faces = np.array(faces).T
labels = np.array(labels)

print("Faces matrix:", faces.shape)

# ---------------- PCA BASE ---------------- #

print("Calculating mean face...")
mean_face = np.mean(faces, axis=1).reshape(-1, 1)
A = faces - mean_face

print("Calculating surrogate covariance...")
C = np.dot(A.T, A)

print("Finding eigen vectors...")
eigvals, eigvecs = np.linalg.eigh(C)
idx = np.argsort(-eigvals)
eigvecs = eigvecs[:, idx]

# ---------------- ACCURACY vs K EXPERIMENT ---------------- #

k_values = [5, 10, 20, 30, 50, 80, 100]
acc_list = []

for K in k_values:
    print("\nTesting for k =", K)

    W = eigvecs[:, :K]
    eigenfaces = np.dot(A, W)
    eigenfaces = eigenfaces / np.linalg.norm(eigenfaces, axis=0)
    eigenfaces = np.real(eigenfaces)

    features = np.dot(eigenfaces.T, A)
    X = features.T
    y = labels

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.4, random_state=42, stratify=y
    )

    model = MLPClassifier(hidden_layer_sizes=(100,), max_iter=600)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)

    print("Accuracy:", acc)
    acc_list.append(acc)

# ---------------- GRAPH ---------------- #

plt.plot(k_values, acc_list, marker='o')
plt.xlabel("k (Number of Eigenfaces)")
plt.ylabel("Accuracy")
plt.title("Accuracy vs k (PCA + ANN Face Recognition)")
plt.grid()
plt.show()   # close this window to continue

# ---------------- IMPOSTER TESTING ---------------- #

print("\n--- IMPOSTER TESTING ---")

THRESHOLD = 0.95   # probability threshold

BEST_K = k_values[acc_list.index(max(acc_list))]
print("Best K selected:", BEST_K)

W = eigvecs[:, :BEST_K]
eigenfaces = np.dot(A, W)
eigenfaces = eigenfaces / np.linalg.norm(eigenfaces, axis=0)
eigenfaces = np.real(eigenfaces)

features = np.dot(eigenfaces.T, A)
X = features.T
y = labels

model = MLPClassifier(hidden_layer_sizes=(100,), max_iter=600)
model.fit(X, y)

# Mean feature of enrolled faces (for distance checking)
mean_feature = np.mean(X, axis=0)

for img_name in os.listdir(IMPOSTER_PATH):
    img_path = os.path.join(IMPOSTER_PATH, img_name)
    img = cv2.imread(img_path, 0)

    if img is None:
        print(img_name, "-> could not read image")
        continue

    img = cv2.resize(img, IMG_SIZE)
    img_vec = img.flatten().reshape(-1,1)
    img_vec = img_vec - mean_face

    test_feature = np.dot(eigenfaces.T, img_vec).T
    probs = model.predict_proba(test_feature)[0]

    dist = np.linalg.norm(test_feature - mean_feature)

    if max(probs) < THRESHOLD or dist > 1500:
        print(img_name, "-> ❌ IMPOSTER (Not in database)")
    else:
        print(img_name, "-> ⚠ Recognized as enrolled person")
