# PCA + ANN Face Recognition System

This project implements a complete face recognition system using **Principal Component Analysis (PCA / Eigenfaces)** for feature extraction and an **Artificial Neural Network (ANN)** for classification, along with **imposter (unknown face) detection**.

The goal of this project is to demonstrate how classical machine learning and linear algebra techniques can be applied to build a real-world biometric system.

---

## 🚀 Features

- Face database creation from image folders  
- Image preprocessing and mean normalization  
- Surrogate covariance matrix computation  
- Eigenface extraction using PCA  
- Feature vector generation  
- ANN training and testing (60–40 split)  
- Accuracy vs k (number of eigenfaces) analysis  
- Automatic best-k selection  
- Imposter detection using confidence + distance threshold  

---

## 🧠 Technologies Used

- Python  
- OpenCV  
- NumPy  
- Scikit-learn  
- Matplotlib  

---

## 📂 Dataset

The dataset is provided as a compressed file due to GitHub upload limitations.

Download and extract (faces) :
https://1drv.ms/f/c/bafa14fb37ee9427/IgB-BQyQpzP4SoJv9DAPG1V1AV92_Lh1cXhFZoZ8GMBzzsI?e=LigbHR

This project implements a complete face recognition system using **Principal Component Analysis (PCA / Eigenfaces)** for feature extraction and an **Artificial Neural Network (ANN)** for classification, along with **imposter (unknown face) detection**.

The goal of this project is to demonstrate how classical machine learning and linear algebra techniques can be applied to build a real-world biometric system.

inside the project directory.

---

## ▶ How to Run

Install required libraries:

```bash
pip install -r requirements.txt

## ▶ How to Run the main file
python main.py

📊 Output
Accuracy vs k graph
Console-based recognition results
Successful rejection of non-enrolled users (imposters)

🎯 Learning Outcomes
Practical understanding of PCA and eigenfaces
Application of ANN for multi-class classification
Hands-on experience with dimensionality reduction

🔮 Future Scope
Real-time face recognition using webcam
CNN-based deep learning approach
Larger and more diverse datasets
Face alignment and illumination normalization
GUI or web-based interface
